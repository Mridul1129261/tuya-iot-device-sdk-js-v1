package com.tuya.smart.android.demo.shortcut;

public interface IShortcutOperateView {
    void updateView();
}
