package com.tuya.smart.android.demo.family.model;

import com.tuya.smart.home.sdk.callback.ITuyaGetHomeListCallback;

public interface IFamilyIndexModel {


    void queryHomeList(ITuyaGetHomeListCallback callback);


}
