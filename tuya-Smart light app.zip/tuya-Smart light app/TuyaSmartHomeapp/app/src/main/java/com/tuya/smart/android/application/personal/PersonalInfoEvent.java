package com.tuya.smart.android.demo.personal;



/**
 * Created by letian on 15/6/22.
 */
public interface PersonalInfoEvent {
    void onEvent(PersonalInfoEventModel event);
}
