package com.tuya.smart.android.demo.shortcut;

import android.text.SpannableString;

public class OperateBean {
    private SpannableString content;
    private String id;

    public SpannableString getContent() {
        return content;
    }

    public void setContent(SpannableString content) {
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
