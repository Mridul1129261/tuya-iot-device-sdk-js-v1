package com.tuya.smart.android.demo.family.activity;

import android.content.Context;

public interface IFamilyAddView {

    Context getContext();

    void doSaveSuccess();

    void doSaveFailed();

}
