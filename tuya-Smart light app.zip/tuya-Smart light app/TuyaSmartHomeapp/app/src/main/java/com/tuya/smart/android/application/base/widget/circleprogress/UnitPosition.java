package com.tuya.smart.android.demo.base.widget.circleprogress;

/**
 * Created by Jakob on 20.11.2015.
 */
public enum UnitPosition {
    TOP,
    BOTTOM,
    LEFT_TOP,
    RIGHT_TOP,
    LEFT_BOTTOM,
    RIGHT_BOTTOM

}
