var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean =
[
    [ "getDay", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#a73aed1310c52a6fded96a95d84ea3e9e", null ],
    [ "getHour", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#a153df8484358937c0d414a895e2e92bb", null ],
    [ "getMonth", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#a1202e8eb954fdb5a44ff15c3e17c6b57", null ],
    [ "getValue", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#ab98463b8e859acf85e786bc5bc51c2e9", null ],
    [ "getWeek", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#a2752bb68517db9b072bb9ba3c13c6783", null ],
    [ "getYear", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#aaf906c82d1b83db4039e1b12da36db4e", null ],
    [ "setDay", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#ac7b630edcbfd96fa8ecbf0ad99683ca4", null ],
    [ "setHour", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#a45bf068745500ec80b3b63889e487e0e", null ],
    [ "setMonth", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#abd15f3fe811b86acd9ac99d891e60ea4", null ],
    [ "setValue", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#ae0e0f6580cfebfa53588bf631ecf6628", null ],
    [ "setWeek", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#a111fc3fbe4ad302a8b2b4f15d0fab363", null ],
    [ "setYear", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html#a01463e3d74d92d7eb4cd3149d7da079e", null ]
];