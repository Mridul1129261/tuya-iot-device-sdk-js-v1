var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_hardware_upgrade_bean =
[
    [ "getDev", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_hardware_upgrade_bean.html#ae4c119023539104b0177570ef422d9f7", null ],
    [ "getGw", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_hardware_upgrade_bean.html#a3521ac5743c42c6ff753cafe99ec68af", null ],
    [ "setDev", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_hardware_upgrade_bean.html#afe1ff67d735b73f604b399b9d4ee1ed8", null ],
    [ "setGw", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_hardware_upgrade_bean.html#a11c47b8cdd64ad6ab2ce3f0244aaf1da", null ]
];