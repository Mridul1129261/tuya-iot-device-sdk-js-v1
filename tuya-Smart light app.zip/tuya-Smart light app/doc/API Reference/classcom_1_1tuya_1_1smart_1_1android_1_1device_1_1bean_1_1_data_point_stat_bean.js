var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_stat_bean =
[
    [ "getData", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_stat_bean.html#afef6e35f5b0e810a76d3cde04f59878b", null ],
    [ "getTotal", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_stat_bean.html#a684fb9a9dffef5c685e9a2216b0d811d", null ],
    [ "setData", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_stat_bean.html#a50f753f62858e2cb1dbae3c1ef5a0f09", null ],
    [ "setTotal", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_stat_bean.html#ad384db48da8f4fa1e6a304b20dc45a93", null ]
];