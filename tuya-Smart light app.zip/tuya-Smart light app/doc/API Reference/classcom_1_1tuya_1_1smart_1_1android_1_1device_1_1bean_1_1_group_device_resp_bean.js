var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean =
[
    [ "getDevId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a6e688b1a31c9a376e45e5c4996be2c76", null ],
    [ "getDevName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a5b660a16ee7f6cc55cefbb5caf2fb90a", null ],
    [ "getGwId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#af2d05f315d1986601341a7f9f69c17b3", null ],
    [ "getGwName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a96d058b3e6631ffcdafcfa59341eb572", null ],
    [ "getIconUrl", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a26b041de830f827d562b148571bab6f7", null ],
    [ "getProductId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#ac5e91d4febb35d61b80df1d373c51aa3", null ],
    [ "isChecked", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#ab0cff7b60521ebd228536585fcd60528", null ],
    [ "isDevOnline", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a1c0d201a21b86215ab60eb125c9d3afb", null ],
    [ "isGwOnline", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a2adef1fbacf21da9a11673fb4fdff0a9", null ],
    [ "setChecked", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#af9a65e3d6691417bc0fd47c9916f1cdc", null ],
    [ "setDevId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#aa6587668ef3c43200c027178eed5ea7e", null ],
    [ "setDevName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a677b0ae9d31c0d8c3d4eb1304f450c5b", null ],
    [ "setDevOnline", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#aee11d36b6a1dfac1fdb4d2e6445c7a89", null ],
    [ "setGwId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a10dc39f4acf58a8285729a025702ab6c", null ],
    [ "setGwName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#af7336959102e3684f03e77710ee98db2", null ],
    [ "setGwOnline", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#af065aa4053d65ab7ab626ce80649f21a", null ],
    [ "setIconUrl", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a4f9ff93bdf23432b33165100bd6f5fd0", null ],
    [ "setProductId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a0dca93fb3f9151b632ef43b927e84a6c", null ],
    [ "toString", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html#a23b86d948255c3aaaa89c9979b6c3a70", null ]
];