var classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean =
[
    [ "getCid", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#a83d2d74d132e7dc3009b47b6cf72c884", null ],
    [ "getDevId", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#a1e3b7677a77a99efd8428a933f86ec5a", null ],
    [ "getEdata", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#aee5e03f017d8281dfd8379447c4ace19", null ],
    [ "getEtype", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#ae225f3c0076597422df35515ec96ffa0", null ],
    [ "getTimestamp", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#ae3a35da5607fe32c76d6bdf6b7557531", null ],
    [ "setCid", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#abf3929649da0b7775c893708150f0ebd", null ],
    [ "setDevId", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#a25b9bb460a98dcce2566a107c008e680", null ],
    [ "setEdata", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#acdc1301598178e32165d462a961066cc", null ],
    [ "setEtype", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#aa5ed23740d4f41d2bb95be3ebd443431", null ],
    [ "setTimestamp", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html#adc57dab32e1e511f7c829b5e993bde87", null ]
];