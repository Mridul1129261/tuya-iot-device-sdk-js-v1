var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean =
[
    [ "MultiGroupBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean" ],
    [ "ParentRulesBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_parent_rules_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_parent_rules_bean" ],
    [ "getMultiGroup", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean.html#a9e0757716f2e45170a1868de0a67a121", null ],
    [ "getParentRules", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean.html#ac5daad4437bf1da85794976334828b65", null ],
    [ "setMultiGroup", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean.html#a8b396009419e03ecbb4b2ac8b42183b0", null ],
    [ "setParentRules", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean.html#a40c53ff3150a01561e9450d8112499ea", null ]
];