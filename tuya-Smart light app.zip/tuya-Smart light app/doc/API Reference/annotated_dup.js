var annotated_dup =
[
    [ "com", null, [
      [ "tuya", null, [
        [ "smart", null, [
          [ "android", null, [
            [ "ble", null, [
              [ "api", "namespacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api.html", [
                [ "BleConfigType", "enumcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_config_type.html", "enumcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_config_type" ],
                [ "BleConnectStatusListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_connect_status_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_connect_status_listener" ],
                [ "BleControllerBean", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean" ],
                [ "BleControllerUpdateBean", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_update_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_update_bean" ],
                [ "BleLogCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_log_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_log_callback" ],
                [ "BleRssiListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_rssi_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_rssi_listener" ],
                [ "BleWiFiDeviceBean", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean" ],
                [ "BluetoothStateChangedListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_bluetooth_state_changed_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_bluetooth_state_changed_listener" ],
                [ "ConfigErrorBean", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_config_error_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_config_error_bean" ],
                [ "DataChannelListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_data_channel_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_data_channel_listener" ],
                [ "ITuyaBleConfigListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_i_tuya_ble_config_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_i_tuya_ble_config_listener" ],
                [ "LeConnectResponse", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_le_connect_response.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_le_connect_response" ],
                [ "LeConnectStatusResponse", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_le_connect_status_response.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_le_connect_status_response" ],
                [ "LeScanSetting", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_le_scan_setting.html", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_le_scan_setting" ],
                [ "OnBleActivatorListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_activator_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_activator_listener" ],
                [ "OnBleConnectListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_connect_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_connect_listener" ],
                [ "OnBleDataTransferListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_data_transfer_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_data_transfer_listener" ],
                [ "OnBleMultiModeDevStatusListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_multi_mode_dev_status_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_multi_mode_dev_status_listener" ],
                [ "OnBleRevChannelListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_rev_channel_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_rev_channel_listener" ],
                [ "OnBleSendChannelListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_send_channel_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_send_channel_listener" ],
                [ "OnBleUpgradeListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_upgrade_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_on_ble_upgrade_listener" ],
                [ "ScanDeviceBean", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_scan_device_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_scan_device_bean" ],
                [ "ScanType", "enumcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_scan_type.html", "enumcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_scan_type" ],
                [ "TyBleScanResponse", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ty_ble_scan_response.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ty_ble_scan_response" ]
              ] ],
              [ "builder", "namespacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1builder.html", [
                [ "BleConnectBuilder", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1builder_1_1_ble_connect_builder.html", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1builder_1_1_ble_connect_builder" ]
              ] ],
              [ "ITuyaBeaconManager", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1_i_tuya_beacon_manager.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1_i_tuya_beacon_manager" ],
              [ "ITuyaBleController", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1_i_tuya_ble_controller.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1_i_tuya_ble_controller" ],
              [ "ITuyaBleManager", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1_i_tuya_ble_manager.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1_i_tuya_ble_manager" ],
              [ "ITuyaBleOperator", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1_i_tuya_ble_operator.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1ble_1_1_i_tuya_ble_operator" ]
            ] ],
            [ "blemesh", null, [
              [ "api", "namespacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api.html", [
                [ "BusinessResultListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_business_result_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_business_result_listener" ],
                [ "ITuyaBlueMeshActivatorListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_activator_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_activator_listener" ],
                [ "ITuyaBlueMeshBusiness", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_business.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_business" ],
                [ "ITuyaBlueMeshClient", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_client.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_client" ],
                [ "ITuyaBlueMeshConfig", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_config.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_config" ],
                [ "ITuyaBlueMeshDevice", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_device.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_device" ],
                [ "ITuyaBlueMeshGroup", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_group.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_group" ],
                [ "ITuyaBlueMeshInit", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_init.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_init" ],
                [ "ITuyaBlueMeshOta", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_ota.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_ota" ],
                [ "ITuyaBlueMeshSearch", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_search.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_search" ],
                [ "ITuyaBlueMeshSearchListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_search_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_blue_mesh_search_listener" ],
                [ "ITuyaSigMeshClient", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_sig_mesh_client.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_i_tuya_sig_mesh_client" ],
                [ "MeshUpgradeListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_mesh_upgrade_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1api_1_1_mesh_upgrade_listener" ]
              ] ],
              [ "bean", "namespacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean.html", [
                [ "BLEUpgradeBean", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_bean" ],
                [ "BLEUpgradeInfoBean", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_info_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_info_bean" ],
                [ "DpsParseBean", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_dps_parse_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_dps_parse_bean" ],
                [ "MeshClientStatusEnum", "enumcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_mesh_client_status_enum.html", "enumcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_mesh_client_status_enum" ],
                [ "MeshLogUploadDataBean", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_mesh_log_upload_data_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_mesh_log_upload_data_bean" ]
              ] ],
              [ "builder", "namespacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1builder.html", [
                [ "SearchBuilder", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1builder_1_1_search_builder.html", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1builder_1_1_search_builder" ],
                [ "TuyaBlueMeshActivatorBuilder", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1builder_1_1_tuya_blue_mesh_activator_builder.html", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1builder_1_1_tuya_blue_mesh_activator_builder" ],
                [ "TuyaBlueMeshOtaBuilder", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1builder_1_1_tuya_blue_mesh_ota_builder.html", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1builder_1_1_tuya_blue_mesh_ota_builder" ],
                [ "TuyaSigMeshActivatorBuilder", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1builder_1_1_tuya_sig_mesh_activator_builder.html", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1builder_1_1_tuya_sig_mesh_activator_builder" ]
              ] ],
              [ "callback", "namespacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1callback.html", [
                [ "ILocalQueryGroupDevCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1callback_1_1_i_local_query_group_dev_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1callback_1_1_i_local_query_group_dev_callback" ]
              ] ],
              [ "ITuyaMeshService", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1_i_tuya_mesh_service.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1_i_tuya_mesh_service" ]
            ] ],
            [ "camera", null, [
              [ "api", null, [
                [ "bean", "namespacecom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean.html", [
                  [ "CameraPushDataBean", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1bean_1_1_camera_push_data_bean" ]
                ] ],
                [ "ITuyaHomeCamera", "interfacecom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1_i_tuya_home_camera.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1camera_1_1api_1_1_i_tuya_home_camera" ]
              ] ]
            ] ],
            [ "config", null, [
              [ "bean", "namespacecom_1_1tuya_1_1smart_1_1android_1_1config_1_1bean.html", [
                [ "ConfigErrorRespBean", "classcom_1_1tuya_1_1smart_1_1android_1_1config_1_1bean_1_1_config_error_resp_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1config_1_1bean_1_1_config_error_resp_bean" ]
              ] ]
            ] ],
            [ "device", null, [
              [ "api", "namespacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1api.html", [
                [ "IGetDataPointStatCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1api_1_1_i_get_data_point_stat_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1api_1_1_i_get_data_point_stat_callback" ],
                [ "IPropertyCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1api_1_1_i_property_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1api_1_1_i_property_callback" ],
                [ "ITuyaDeviceMultiControl", "interfacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1api_1_1_i_tuya_device_multi_control.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1api_1_1_i_tuya_device_multi_control" ]
              ] ],
              [ "bean", "namespacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean.html", [
                [ "AlarmTimerBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_alarm_timer_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_alarm_timer_bean" ],
                [ "BitmapSchemaBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bitmap_schema_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bitmap_schema_bean" ],
                [ "BoolSchemaBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bool_schema_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bool_schema_bean" ],
                [ "DataPointBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_bean" ],
                [ "DataPointStatBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_stat_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_data_point_stat_bean" ],
                [ "DeviceDpInfoBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean" ],
                [ "DeviceInfoBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_info_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_info_bean" ],
                [ "DeviceMultiControlRelationBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean" ],
                [ "DevLocationBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_dev_location_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_dev_location_bean" ],
                [ "EnumSchemaBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_enum_schema_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_enum_schema_bean" ],
                [ "GroupDeviceRespBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_group_device_resp_bean" ],
                [ "HardwareUpgradeBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_hardware_upgrade_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_hardware_upgrade_bean" ],
                [ "MultiControlBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean" ],
                [ "MultiControlDataPointsBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_data_points_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_data_points_bean" ],
                [ "MultiControlDevInfoBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_dev_info_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_dev_info_bean" ],
                [ "MultiControlLinkBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean" ],
                [ "SchemaBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_schema_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_schema_bean" ],
                [ "StringSchemaBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_string_schema_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_string_schema_bean" ],
                [ "UpgradeInfoBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_upgrade_info_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_upgrade_info_bean" ],
                [ "ValueSchemaBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_value_schema_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_value_schema_bean" ]
              ] ],
              [ "builder", "namespacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1builder.html", [
                [ "TuyaTimerBuilder", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1builder_1_1_tuya_timer_builder.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1builder_1_1_tuya_timer_builder" ]
              ] ],
              [ "enums", "namespacecom_1_1tuya_1_1smart_1_1android_1_1device_1_1enums.html", [
                [ "DataPointTypeEnum", "enumcom_1_1tuya_1_1smart_1_1android_1_1device_1_1enums_1_1_data_point_type_enum.html", "enumcom_1_1tuya_1_1smart_1_1android_1_1device_1_1enums_1_1_data_point_type_enum" ],
                [ "DataTypeEnum", "enumcom_1_1tuya_1_1smart_1_1android_1_1device_1_1enums_1_1_data_type_enum.html", "enumcom_1_1tuya_1_1smart_1_1android_1_1device_1_1enums_1_1_data_type_enum" ],
                [ "ModeEnum", "enumcom_1_1tuya_1_1smart_1_1android_1_1device_1_1enums_1_1_mode_enum.html", "enumcom_1_1tuya_1_1smart_1_1android_1_1device_1_1enums_1_1_mode_enum" ],
                [ "TimerDeviceTypeEnum", "enumcom_1_1tuya_1_1smart_1_1android_1_1device_1_1enums_1_1_timer_device_type_enum.html", "enumcom_1_1tuya_1_1smart_1_1android_1_1device_1_1enums_1_1_timer_device_type_enum" ]
              ] ]
            ] ],
            [ "mqtt", "namespacecom_1_1tuya_1_1smart_1_1android_1_1mqtt.html", [
              [ "ITuyaMqttChannel", "interfacecom_1_1tuya_1_1smart_1_1android_1_1mqtt_1_1_i_tuya_mqtt_channel.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1mqtt_1_1_i_tuya_mqtt_channel" ],
              [ "ITuyaMqttRetainChannelListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1mqtt_1_1_i_tuya_mqtt_retain_channel_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1mqtt_1_1_i_tuya_mqtt_retain_channel_listener" ],
              [ "MqttMessageBean", "classcom_1_1tuya_1_1smart_1_1android_1_1mqtt_1_1_mqtt_message_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1mqtt_1_1_mqtt_message_bean" ]
            ] ],
            [ "push", null, [
              [ "bean", null, [
                [ "enums", "namespacecom_1_1tuya_1_1smart_1_1android_1_1push_1_1bean_1_1enums.html", [
                  [ "PushAlarmType", "enumcom_1_1tuya_1_1smart_1_1android_1_1push_1_1bean_1_1enums_1_1_push_alarm_type.html", "enumcom_1_1tuya_1_1smart_1_1android_1_1push_1_1bean_1_1enums_1_1_push_alarm_type" ]
                ] ],
                [ "PushAlarmBean", "classcom_1_1tuya_1_1smart_1_1android_1_1push_1_1bean_1_1_push_alarm_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1push_1_1bean_1_1_push_alarm_bean" ],
                [ "SecurityAlermBean", "classcom_1_1tuya_1_1smart_1_1android_1_1push_1_1bean_1_1_security_alerm_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1push_1_1bean_1_1_security_alerm_bean" ]
              ] ]
            ] ],
            [ "sweeper", null, [
              [ "bean", "namespacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean.html", [
                [ "CloudConfigBean", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_cloud_config_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_cloud_config_bean" ],
                [ "PathConfig", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_path_config.html", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_path_config" ],
                [ "SweeperByteData", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_byte_data.html", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_byte_data" ],
                [ "SweeperDataBean", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_data_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_data_bean" ],
                [ "SweeperHistory", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_history.html", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_history" ],
                [ "SweeperHistoryBean", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_history_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_history_bean" ],
                [ "SweeperPathBean", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_path_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1bean_1_1_sweeper_path_bean" ]
              ] ],
              [ "ITuyaByteDataListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_byte_data_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_byte_data_listener" ],
              [ "ITuyaCloudConfigCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_cloud_config_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_cloud_config_callback" ],
              [ "ITuyaDelHistoryCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_del_history_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_del_history_callback" ],
              [ "ITuyaSweeper", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_sweeper.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_sweeper" ],
              [ "ITuyaSweeperByteDataListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_sweeper_byte_data_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_sweeper_byte_data_listener" ],
              [ "ITuyaSweeperDataListener", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_sweeper_data_listener.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1sweeper_1_1_i_tuya_sweeper_data_listener" ]
            ] ],
            [ "user", null, [
              [ "api", "namespacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api.html", [
                [ "IBooleanCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_boolean_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_boolean_callback" ],
                [ "ICheckAccountCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_check_account_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_check_account_callback" ],
                [ "ICommonConfigCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_common_config_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_common_config_callback" ],
                [ "IGetQRCodeTokenCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_get_q_r_code_token_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_get_q_r_code_token_callback" ],
                [ "IGetQRDeviceInfoCallBack", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_get_q_r_device_info_call_back.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_get_q_r_device_info_call_back" ],
                [ "IGetRegionCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_get_region_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_get_region_callback" ],
                [ "ILoginCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_login_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_login_callback" ],
                [ "ILogoutCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_logout_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_logout_callback" ],
                [ "IQurryDomainCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_qurry_domain_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_qurry_domain_callback" ],
                [ "IRegisterCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_register_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_register_callback" ],
                [ "IReNickNameCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_re_nick_name_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_re_nick_name_callback" ],
                [ "IResetPasswordCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_reset_password_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_reset_password_callback" ],
                [ "IUidLoginCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_uid_login_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_uid_login_callback" ],
                [ "IUserStorage", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_user_storage.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_user_storage" ],
                [ "IValidateCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_validate_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_validate_callback" ],
                [ "IWhiteListCallback", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_white_list_callback.html", "interfacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1api_1_1_i_white_list_callback" ]
              ] ],
              [ "bean", "namespacecom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean.html", [
                [ "CommonConfigBean", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_common_config_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_common_config_bean" ],
                [ "Domain", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_domain.html", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_domain" ],
                [ "QRDeviceInfoBean", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_q_r_device_info_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_q_r_device_info_bean" ],
                [ "Region", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_region.html", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_region" ],
                [ "User", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_user.html", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_user" ],
                [ "WhiteList", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_white_list.html", "classcom_1_1tuya_1_1smart_1_1android_1_1user_1_1bean_1_1_white_list" ]
              ] ]
            ] ]
          ] ],
          [ "home", null, [
            [ "sdk", null, [
              [ "anntation", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1anntation.html", [
                [ "HomeStatus", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1anntation_1_1_home_status.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1anntation_1_1_home_status" ],
                [ "MemberRole", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1anntation_1_1_member_role.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1anntation_1_1_member_role" ],
                [ "MemberStatus", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1anntation_1_1_member_status.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1anntation_1_1_member_status" ],
                [ "PanelType", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1anntation_1_1_panel_type.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1anntation_1_1_panel_type" ]
              ] ],
              [ "api", null, [
                [ "config", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config.html", [
                  [ "IApConnectListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_ap_connect_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_ap_connect_listener" ],
                  [ "IBaseConnectListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_base_connect_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_base_connect_listener" ],
                  [ "IConfig", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_config.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_config" ],
                  [ "IConnectListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_connect_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_connect_listener" ],
                  [ "IGwConfigListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_gw_config_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1config_1_1_i_gw_config_listener" ]
                ] ],
                [ "IActivator", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_activator.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_activator" ],
                [ "IDevModel", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_dev_model.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_dev_model" ],
                [ "IGwSearchListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_gw_search_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_gw_search_listener" ],
                [ "IHomeCacheManager", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_home_cache_manager.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_home_cache_manager" ],
                [ "IHomePatchCacheManager", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_home_patch_cache_manager.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_home_patch_cache_manager" ],
                [ "ITuyaDeviceActivator", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_device_activator.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_device_activator" ],
                [ "ITuyaGroupModel", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_group_model.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_group_model" ],
                [ "ITuyaGwActivator", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_gw_activator.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_gw_activator" ],
                [ "ITuyaGwSearcher", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_gw_searcher.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_gw_searcher" ],
                [ "ITuyaHome", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home" ],
                [ "ITuyaHomeChangeListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_change_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_change_listener" ],
                [ "ITuyaHomeDataManager", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_data_manager.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_data_manager" ],
                [ "ITuyaHomeDeviceShare", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_device_share.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_device_share" ],
                [ "ITuyaHomeDeviceStatusListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_device_status_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_device_status_listener" ],
                [ "ITuyaHomeManager", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_manager.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_manager" ],
                [ "ITuyaHomeMember", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_member.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_member" ],
                [ "ITuyaHomePatch", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_patch.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_patch" ],
                [ "ITuyaHomeScene", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_scene.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_scene" ],
                [ "ITuyaHomeSceneManager", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_scene_manager.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_scene_manager" ],
                [ "ITuyaHomeSpeech", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_speech.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_speech" ],
                [ "ITuyaHomeStatusListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_status_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_home_status_listener" ],
                [ "ITuyaLightningActivator", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_lightning_activator.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_lightning_activator" ],
                [ "ITuyaLightningSearcher", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_lightning_searcher.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_lightning_searcher" ],
                [ "ITuyaLightningSearchListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_lightning_search_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_lightning_search_listener" ],
                [ "ITuyaRoom", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_room.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_room" ],
                [ "ITuyaServer", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_server.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_server" ],
                [ "ITuyaZigBeeConfigLocalSceneCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_zig_bee_config_local_scene_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_zig_bee_config_local_scene_callback" ],
                [ "ITuyaZigBeeLocalScene", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_zig_bee_local_scene.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_tuya_zig_bee_local_scene" ],
                [ "IWarningMsgListener", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_warning_msg_listener.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1api_1_1_i_warning_msg_listener" ]
              ] ],
              [ "bean", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean.html", [
                [ "scene", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene.html", [
                  [ "condition", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition.html", [
                    [ "property", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property.html", [
                      [ "BoolProperty", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property_1_1_bool_property.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property_1_1_bool_property" ],
                      [ "EnumProperty", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property_1_1_enum_property.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property_1_1_enum_property" ],
                      [ "IProperty", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property_1_1_i_property.html", null ],
                      [ "TimerProperty", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property_1_1_timer_property.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property_1_1_timer_property" ],
                      [ "ValueProperty", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property_1_1_value_property.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1property_1_1_value_property" ]
                    ] ],
                    [ "rule", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule.html", [
                      [ "Arithmetic", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_arithmetic.html", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_arithmetic" ],
                      [ "BoolRule", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_bool_rule.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_bool_rule" ],
                      [ "EnumRule", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_enum_rule.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_enum_rule" ],
                      [ "Rule", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_rule.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_rule" ],
                      [ "TimerRule", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_timer_rule.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_timer_rule" ],
                      [ "ValueRule", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_value_rule.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1rule_1_1_value_rule" ]
                    ] ],
                    [ "ConditionListBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1_condition_list_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1_condition_list_bean" ],
                    [ "GeoType", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1_geo_type.html", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1condition_1_1_geo_type" ]
                  ] ],
                  [ "dev", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1dev.html", [
                    [ "TaskListBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1dev_1_1_task_list_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1dev_1_1_task_list_bean" ]
                  ] ],
                  [ "ActionBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_action_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_action_bean" ],
                  [ "ActRespBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_act_resp_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_act_resp_bean" ],
                  [ "ConditionActionBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_condition_action_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_condition_action_bean" ],
                  [ "ConditionAllBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_condition_all_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_condition_all_bean" ],
                  [ "ConditionExtraInfoBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_condition_extra_info_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_condition_extra_info_bean" ],
                  [ "ConditionRespBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_condition_resp_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_condition_resp_bean" ],
                  [ "FunctionDataPoint", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_function_data_point.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_function_data_point" ],
                  [ "FunctionListBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_function_list_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_function_list_bean" ],
                  [ "LocalSceneBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_local_scene_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_local_scene_bean" ],
                  [ "MCGroup", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_m_c_group.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_m_c_group" ],
                  [ "PlaceFacadeBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_place_facade_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_place_facade_bean" ],
                  [ "PreCondition", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_pre_condition.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_pre_condition" ],
                  [ "PreConditionExpr", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_pre_condition_expr.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_pre_condition_expr" ],
                  [ "SceneAppearance", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_appearance.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_appearance" ],
                  [ "SceneAuthBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_auth_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_auth_bean" ],
                  [ "SceneBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_bean" ],
                  [ "SceneCondition", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_condition.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_condition" ],
                  [ "SceneIdBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_id_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_id_bean" ],
                  [ "SceneLogDetailBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_log_detail_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_log_detail_bean" ],
                  [ "SceneLogResBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_log_res_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_log_res_bean" ],
                  [ "SceneTask", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_task.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_task" ],
                  [ "SceneTaskGroupDevice", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_task_group_device.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1scene_1_1_scene_task_group_device" ]
                ] ],
                [ "ActiveDmDeviceBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_active_dm_device_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_active_dm_device_bean" ],
                [ "ConfigProductInfoBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_config_product_info_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_config_product_info_bean" ],
                [ "DashBoardBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_dash_board_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_dash_board_bean" ],
                [ "DeviceAndGroupInHomeBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_and_group_in_home_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_and_group_in_home_bean" ],
                [ "DeviceAndGroupInRoomBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_and_group_in_room_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_and_group_in_room_bean" ],
                [ "DeviceBizPropBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_biz_prop_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_biz_prop_bean" ],
                [ "DeviceShareBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_share_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_share_bean" ],
                [ "DeviceType", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_type.html", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_device_type" ],
                [ "EnvBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_env_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_env_bean" ],
                [ "HomeBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_home_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_home_bean" ],
                [ "LightningSearchBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_lightning_search_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_lightning_search_bean" ],
                [ "MemberBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_member_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_member_bean" ],
                [ "MemberWrapperBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_member_wrapper_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_member_wrapper_bean" ],
                [ "MessageHasNew", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_message_has_new.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_message_has_new" ],
                [ "PersonBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_person_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_person_bean" ],
                [ "ProductRefBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_product_ref_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_product_ref_bean" ],
                [ "RoomAuthBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_room_auth_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_room_auth_bean" ],
                [ "RoomBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_room_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_room_bean" ],
                [ "SharedUserInfoBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_shared_user_info_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_shared_user_info_bean" ],
                [ "ShareInfoFromDevBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_share_info_from_dev_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_share_info_from_dev_bean" ],
                [ "ShareReceivedUserDetailBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_share_received_user_detail_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_share_received_user_detail_bean" ],
                [ "SharerInfoBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_sharer_info_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_sharer_info_bean" ],
                [ "ShareSentUserDetailBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_share_sent_user_detail_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_share_sent_user_detail_bean" ],
                [ "SpeechGuideBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_speech_guide_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_speech_guide_bean" ],
                [ "SpeechPhraseBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_speech_phrase_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_speech_phrase_bean" ],
                [ "TransferDataBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_transfer_data_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_transfer_data_bean" ],
                [ "UniversalBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_universal_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_universal_bean" ],
                [ "VoiceCommandBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_voice_command_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_voice_command_bean" ],
                [ "WarnMessageBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_warn_message_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_warn_message_bean" ],
                [ "WeatherBean", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_weather_bean.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1bean_1_1_weather_bean" ]
              ] ],
              [ "builder", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder.html", [
                [ "ActivatorBuilder", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_activator_builder.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_activator_builder" ],
                [ "GroupCreateBuilder", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_group_create_builder.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_group_create_builder" ],
                [ "TuyaAutoConfigActivatorBuilder", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_auto_config_activator_builder.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_auto_config_activator_builder" ],
                [ "TuyaCameraActivatorBuilder", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_camera_activator_builder.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_camera_activator_builder" ],
                [ "TuyaGwActivatorBuilder", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_gw_activator_builder.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_gw_activator_builder" ],
                [ "TuyaGwSubDevActivatorBuilder", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_gw_sub_dev_activator_builder.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_gw_sub_dev_activator_builder" ],
                [ "TuyaLightningDevActivatorBuilder", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_lightning_dev_activator_builder.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_lightning_dev_activator_builder" ],
                [ "TuyaQRCodeActivatorBuilder", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_q_r_code_activator_builder.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1builder_1_1_tuya_q_r_code_activator_builder" ]
              ] ],
              [ "callback", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback.html", [
                [ "IGetHomeWetherCallBack", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_get_home_wether_call_back.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_get_home_wether_call_back" ],
                [ "IIGetHomeWetherSketchCallBack", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_i_get_home_wether_sketch_call_back.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_i_get_home_wether_sketch_call_back" ],
                [ "ITuyaDeviceUpgradeStatusCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_device_upgrade_status_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_device_upgrade_status_callback" ],
                [ "ITuyaDeviceUpgradeStatusExtCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_device_upgrade_status_ext_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_device_upgrade_status_ext_callback" ],
                [ "ITuyaGetHomeListCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_get_home_list_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_get_home_list_callback" ],
                [ "ITuyaGetMemberListCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_get_member_list_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_get_member_list_callback" ],
                [ "ITuyaGetRoomListCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_get_room_list_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_get_room_list_callback" ],
                [ "ITuyaHomeResultCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_home_result_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_home_result_callback" ],
                [ "ITuyaMemberResultCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_member_result_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_member_result_callback" ],
                [ "ITuyaResultCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_result_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_result_callback" ],
                [ "ITuyaRoomResultCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_room_result_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_room_result_callback" ],
                [ "ITuyaSingleTransfer", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_single_transfer.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_single_transfer" ],
                [ "ITuyaTransferCallback", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_transfer_callback.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_transfer_callback" ],
                [ "ITuyaVoiceTransfer", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_voice_transfer.html", "interfacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1callback_1_1_i_tuya_voice_transfer" ]
              ] ],
              [ "constant", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1constant.html", [
                [ "TimerTypeEnum", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1constant_1_1_timer_type_enum.html", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1constant_1_1_timer_type_enum" ],
                [ "TimerUpdateEnum", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1constant_1_1_timer_update_enum.html", "enumcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1constant_1_1_timer_update_enum" ]
              ] ],
              [ "utils", "namespacecom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1utils.html", [
                [ "SchemaMapper", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1utils_1_1_schema_mapper.html", "classcom_1_1tuya_1_1smart_1_1home_1_1sdk_1_1utils_1_1_schema_mapper" ]
              ] ]
            ] ]
          ] ],
          [ "sdk", null, [
            [ "api", null, [
              [ "bluemesh", "namespacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh.html", [
                [ "IAddGroupCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_add_group_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_add_group_callback" ],
                [ "IAddRoomCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_add_room_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_add_room_callback" ],
                [ "IAddSubDevCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_add_sub_dev_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_add_sub_dev_callback" ],
                [ "IBlueMeshActivatorListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_blue_mesh_activator_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_blue_mesh_activator_listener" ],
                [ "IBlueMeshCreateCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_blue_mesh_create_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_blue_mesh_create_callback" ],
                [ "IBlueMeshManager", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_blue_mesh_manager.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_blue_mesh_manager" ],
                [ "IGetGroupAndDevListCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_get_group_and_dev_list_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_get_group_and_dev_list_callback" ],
                [ "IGetMeshRoomAndGroupListCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_get_mesh_room_and_group_list_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_get_mesh_room_and_group_list_callback" ],
                [ "IGroupDevCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_group_dev_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_group_dev_callback" ],
                [ "IMeshDeviceListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_mesh_device_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_mesh_device_listener" ],
                [ "IMeshDevListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_mesh_dev_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_mesh_dev_listener" ],
                [ "IMeshDevListenerV2", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_mesh_dev_listener_v2.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_mesh_dev_listener_v2" ],
                [ "IMeshStatusListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_mesh_status_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_mesh_status_listener" ],
                [ "IRequestMeshListCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_request_mesh_list_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_request_mesh_list_callback" ],
                [ "IRequestSigMeshListCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_request_sig_mesh_list_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_request_sig_mesh_list_callback" ],
                [ "IRequestUpgradeInfoCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_request_upgrade_info_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_request_upgrade_info_callback" ],
                [ "ISigMeshCreateCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_sig_mesh_create_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_sig_mesh_create_callback" ],
                [ "ISigMeshManager", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_sig_mesh_manager.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_sig_mesh_manager" ],
                [ "ITuyaBlueMesh", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_tuya_blue_mesh.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_tuya_blue_mesh" ],
                [ "ITuyaBlueMeshActivator", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_tuya_blue_mesh_activator.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_tuya_blue_mesh_activator" ],
                [ "ITuyaMeshGroup", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_tuya_mesh_group.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_tuya_mesh_group" ],
                [ "ITuyaRoomManager", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_tuya_room_manager.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1bluemesh_1_1_i_tuya_room_manager" ]
              ] ],
              [ "wifibackup", null, [
                [ "api", null, [
                  [ "bean", "namespacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean.html", [
                    [ "BackupWifiBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_backup_wifi_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_backup_wifi_bean" ],
                    [ "BackupWifiListInfo", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_backup_wifi_list_info.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_backup_wifi_list_info" ],
                    [ "BackupWifiResultBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_backup_wifi_result_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_backup_wifi_result_bean" ],
                    [ "BaseInfo", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_base_info.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_base_info" ],
                    [ "CurrentWifiInfoBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_current_wifi_info_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_current_wifi_info_bean" ],
                    [ "SwitchWifiResultBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_switch_wifi_result_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1bean_1_1_switch_wifi_result_bean" ]
                  ] ],
                  [ "ITuyaWifiBackup", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1_i_tuya_wifi_backup.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1_i_tuya_wifi_backup" ],
                  [ "ITuyaWifiBase", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1_i_tuya_wifi_base.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1_i_tuya_wifi_base" ],
                  [ "ITuyaWifiSwitch", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1_i_tuya_wifi_switch.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1wifibackup_1_1api_1_1_i_tuya_wifi_switch" ]
                ] ]
              ] ],
              [ "IBleActivator", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_ble_activator.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_ble_activator" ],
              [ "IBleActivatorListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_ble_activator_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_ble_activator_listener" ],
              [ "ICreateGroupAlarmCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_create_group_alarm_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_create_group_alarm_callback" ],
              [ "ICreateGroupCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_create_group_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_create_group_callback" ],
              [ "IDeviceCache", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_device_cache.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_device_cache" ],
              [ "IDeviceListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_device_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_device_listener" ],
              [ "IDevListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_dev_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_dev_listener" ],
              [ "IDevSceneListUpdateListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_dev_scene_list_update_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_dev_scene_list_update_listener" ],
              [ "IFirmwareUpgradeListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_firmware_upgrade_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_firmware_upgrade_listener" ],
              [ "IGetAllTimerWithDevIdCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_all_timer_with_dev_id_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_all_timer_with_dev_id_callback" ],
              [ "IGetDevicesInGroupCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_devices_in_group_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_devices_in_group_callback" ],
              [ "IGetDeviceTimerStatusCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_device_timer_status_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_device_timer_status_callback" ],
              [ "IGetDevsFromGroupByPidCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_devs_from_group_by_pid_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_devs_from_group_by_pid_callback" ],
              [ "IGetGroupAlarmCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_group_alarm_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_group_alarm_callback" ],
              [ "IGetOtaInfoCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_ota_info_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_ota_info_callback" ],
              [ "IGetSubDevListCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_sub_dev_list_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_sub_dev_list_callback" ],
              [ "IGetTimerWithTaskCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_timer_with_task_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_get_timer_with_task_callback" ],
              [ "IGroupListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_group_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_group_listener" ],
              [ "IMultiModeActivator", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_multi_mode_activator.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_multi_mode_activator" ],
              [ "IMultiModeActivatorListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_multi_mode_activator_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_multi_mode_activator_listener" ],
              [ "INeedLoginListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_need_login_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_need_login_listener" ],
              [ "IOtaListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_ota_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_ota_listener" ],
              [ "IRequestCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_request_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_request_callback" ],
              [ "IResultCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_result_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_result_callback" ],
              [ "IResultStatusCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_result_status_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_result_status_callback" ],
              [ "ISmartUpdateListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_smart_update_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_smart_update_listener" ],
              [ "IStandardConverter", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_standard_converter.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_standard_converter" ],
              [ "IStorageCache", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_storage_cache.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_storage_cache" ],
              [ "ISubDevListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_sub_dev_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_sub_dev_listener" ],
              [ "ITuyaActivator", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_activator.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_activator" ],
              [ "ITuyaActivatorCreateToken", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_activator_create_token.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_activator_create_token" ],
              [ "ITuyaActivatorGetToken", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_activator_get_token.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_activator_get_token" ],
              [ "ITuyaCameraDevActivator", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_camera_dev_activator.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_camera_dev_activator" ],
              [ "ITuyaCommonTimer", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_common_timer.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_common_timer" ],
              [ "ITuyaDataCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_data_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_data_callback" ],
              [ "ITuyaDevActivatorListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_dev_activator_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_dev_activator_listener" ],
              [ "ITuyaDevice", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_device.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_device" ],
              [ "ITuyaDeviceListManager", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_device_list_manager.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_device_list_manager" ],
              [ "ITuyaFeedback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_feedback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_feedback" ],
              [ "ITuyaFeedbackMag", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_feedback_mag.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_feedback_mag" ],
              [ "ITuyaFeedbackManager", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_feedback_manager.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_feedback_manager" ],
              [ "ITuyaGateway", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_gateway.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_gateway" ],
              [ "ITuyaGeoFence", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_geo_fence.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_geo_fence" ],
              [ "ITuyaGeoFenceOperate", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_geo_fence_operate.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_geo_fence_operate" ],
              [ "ITuyaGetBeanCallback", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_get_bean_callback.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_get_bean_callback" ],
              [ "ITuyaGroup", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_group.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_group" ],
              [ "ITuyaMessage", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_message.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_message" ],
              [ "ITuyaOta", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_ota.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_ota" ],
              [ "ITuyaPush", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_push.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_push" ],
              [ "ITuyaQRCodeDevActivator", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_q_r_code_dev_activator.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_q_r_code_dev_activator" ],
              [ "ITuyaSearchDeviceListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_search_device_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_search_device_listener" ],
              [ "ITuyaSmartActivatorListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_activator_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_activator_listener" ],
              [ "ITuyaSmartCameraActivatorListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_camera_activator_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_camera_activator_listener" ],
              [ "ITuyaSmartQRCodeActivatorListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_q_r_code_activator_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_q_r_code_activator_listener" ],
              [ "ITuyaSmartRequest", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_request.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_request" ],
              [ "ITuyaSmartTimer", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_timer.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_smart_timer" ],
              [ "ITuyaTimer", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_timer.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_timer" ],
              [ "ITuyaUser", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_user.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_user" ],
              [ "ITuyaWifiGroup", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_wifi_group.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_wifi_group" ],
              [ "ITuyaZigbeeGroup", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_zigbee_group.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_i_tuya_zigbee_group" ],
              [ "OnTuyaGeoFencesListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_on_tuya_geo_fences_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_on_tuya_geo_fences_listener" ],
              [ "OnTuyaGeoFenceStatusListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_on_tuya_geo_fence_status_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_on_tuya_geo_fence_status_listener" ],
              [ "WifiSignalListener", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_wifi_signal_listener.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1api_1_1_wifi_signal_listener" ]
            ] ],
            [ "bean", "namespacecom_1_1tuya_1_1smart_1_1sdk_1_1bean.html", [
              [ "cache", "namespacecom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1cache.html", [
                [ "CacheObj", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1cache_1_1_cache_obj.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1cache_1_1_cache_obj" ],
                [ "ICacheManager", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1cache_1_1_i_cache_manager.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1cache_1_1_i_cache_manager" ],
                [ "ICacheStore", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1cache_1_1_i_cache_store.html", "interfacecom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1cache_1_1_i_cache_store" ]
              ] ],
              [ "feedback", "namespacecom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback.html", [
                [ "FeedbackBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_bean" ],
                [ "FeedbackMsgBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_msg_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_msg_bean" ],
                [ "FeedbackMsgListBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_msg_list_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_msg_list_bean" ],
                [ "FeedbackTypeBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_type_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_type_bean" ],
                [ "FeedbackTypeRespBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_type_resp_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1feedback_1_1_feedback_type_resp_bean" ]
              ] ],
              [ "message", "namespacecom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message.html", [
                [ "DeviceAlarmNotDisturbVO", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_device_alarm_not_disturb_v_o.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_device_alarm_not_disturb_v_o" ],
                [ "MessageAttach", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_message_attach.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_message_attach" ],
                [ "MessageBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_message_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_message_bean" ],
                [ "MessageListBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_message_list_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_message_list_bean" ],
                [ "MessageType", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_message_type.html", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_message_type" ],
                [ "NodisturbDevicesBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_nodisturb_devices_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1message_1_1_nodisturb_devices_bean" ]
              ] ],
              [ "push", "namespacecom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1push.html", [
                [ "MQCompensationBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1push_1_1_m_q_compensation_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1push_1_1_m_q_compensation_bean" ],
                [ "PushStatusBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1push_1_1_push_status_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1push_1_1_push_status_bean" ],
                [ "PushType", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1push_1_1_push_type.html", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1push_1_1_push_type" ],
                [ "TuyaPushBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1push_1_1_tuya_push_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1push_1_1_tuya_push_bean" ]
              ] ],
              [ "BleActivatorBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_ble_activator_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_ble_activator_bean" ],
              [ "BlueMeshBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_bean" ],
              [ "BlueMeshGroupBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_group_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_group_bean" ],
              [ "BlueMeshModuleMapBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_module_map_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_module_map_bean" ],
              [ "BlueMeshRelationDevBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_relation_dev_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_relation_dev_bean" ],
              [ "BlueMeshRoomBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_room_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_room_bean" ],
              [ "BlueMeshShareBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_share_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_share_bean" ],
              [ "BlueMeshSubDevBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_sub_dev_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_sub_dev_bean" ],
              [ "BlueMeshWifiStatusBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_wifi_status_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_blue_mesh_wifi_status_bean" ],
              [ "BluetoothStatusBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_bluetooth_status_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_bluetooth_status_bean" ],
              [ "CloudZigbeeGroupCreateBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_cloud_zigbee_group_create_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_cloud_zigbee_group_create_bean" ],
              [ "DeviceBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_device_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_device_bean" ],
              [ "DpBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_dp_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_dp_bean" ],
              [ "GroupBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_group_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_group_bean" ],
              [ "GroupDeviceBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_group_device_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_group_device_bean" ],
              [ "GroupShareBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_group_share_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_group_share_bean" ],
              [ "LocationInfo", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_location_info.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_location_info" ],
              [ "MultiModeActivatorBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_multi_mode_activator_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_multi_mode_activator_bean" ],
              [ "OTAErrorMessageBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_o_t_a_error_message_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_o_t_a_error_message_bean" ],
              [ "ProductBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_product_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_product_bean" ],
              [ "ProductStandardConfig", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_product_standard_config.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_product_standard_config" ],
              [ "PushBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_push_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_push_bean" ],
              [ "ShareIdBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_share_id_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_share_id_bean" ],
              [ "ShortCutBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_short_cut_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_short_cut_bean" ],
              [ "SigMeshBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_sig_mesh_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_sig_mesh_bean" ],
              [ "SpeechTTSBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_speech_t_t_s_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_speech_t_t_s_bean" ],
              [ "StandSchema", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_stand_schema.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_stand_schema" ],
              [ "Timer", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_timer.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_timer" ],
              [ "TimerControlBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_timer_control_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_timer_control_bean" ],
              [ "TimerTask", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_timer_task.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_timer_task" ],
              [ "TimerTaskStatus", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_timer_task_status.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_timer_task_status" ],
              [ "TuyaGeoFence", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_tuya_geo_fence.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_tuya_geo_fence" ],
              [ "UiInfo", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_ui_info.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_ui_info" ],
              [ "ZigbeeGroupCreateResultBean", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_zigbee_group_create_result_bean.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1bean_1_1_zigbee_group_create_result_bean" ]
            ] ],
            [ "constant", "namespacecom_1_1tuya_1_1smart_1_1sdk_1_1constant.html", [
              [ "ServiceNotification", "classcom_1_1tuya_1_1smart_1_1sdk_1_1constant_1_1_service_notification.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1constant_1_1_service_notification" ]
            ] ],
            [ "enums", "namespacecom_1_1tuya_1_1smart_1_1sdk_1_1enums.html", [
              [ "ActivatorAPStepCode", "classcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_activator_a_p_step_code.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_activator_a_p_step_code" ],
              [ "ActivatorEZStepCode", "classcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_activator_e_z_step_code.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_activator_e_z_step_code" ],
              [ "ActivatorMeshStepCode", "classcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_activator_mesh_step_code.html", "classcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_activator_mesh_step_code" ],
              [ "ActivatorModelEnum", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_activator_model_enum.html", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_activator_model_enum" ],
              [ "DeviceActiveEnum", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_device_active_enum.html", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_device_active_enum" ],
              [ "FirmwareUpgradeEnum", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_firmware_upgrade_enum.html", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_firmware_upgrade_enum" ],
              [ "TempUnitEnum", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_temp_unit_enum.html", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_temp_unit_enum" ],
              [ "TYDevicePublishModeEnum", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_t_y_device_publish_mode_enum.html", "enumcom_1_1tuya_1_1smart_1_1sdk_1_1enums_1_1_t_y_device_publish_mode_enum" ]
            ] ]
          ] ]
        ] ]
      ] ]
    ] ]
];