var classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_config_error_bean =
[
    [ "devId", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_config_error_bean.html#a5c8780d5d3b9fdc2997fef81b2821c25", null ],
    [ "errorCode", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_config_error_bean.html#a025493287310c781aceca5a81091810e", null ],
    [ "errorMsg", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_config_error_bean.html#a319a7f0c0bf33506c9221c765b4e3a29", null ],
    [ "iconUrl", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_config_error_bean.html#a597fdb2ec72a0b785693f04e7d885299", null ],
    [ "name", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_config_error_bean.html#a88d95d62a24d59bc422f2702a3d0b36d", null ]
];