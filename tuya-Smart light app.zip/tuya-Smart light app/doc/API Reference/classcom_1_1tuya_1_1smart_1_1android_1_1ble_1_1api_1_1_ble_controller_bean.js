var classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean =
[
    [ "address", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a6edb106547c16083e0e106d56568cabc", null ],
    [ "deviceName", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a2dd950b2ccc307370b659fde2dace9e4", null ],
    [ "deviceType", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#ac0ac078e0f831c0f1789dd1e47251e35", null ],
    [ "homeId", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a367adf4e8ee95223c367c89eb11dfbaa", null ],
    [ "isShare", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#af3f705b79f1596f2512d9183c8b34e1e", null ],
    [ "mac", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a08dac768a1e7a253e3858c7d90eadb66", null ],
    [ "onBleActivatorListener", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a734de7e1e8122acba1b27c6afae5b2ac", null ],
    [ "onBleConnectListener", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a3e64423155be8561d0ab7526c02ecf71", null ],
    [ "productId", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a17a1099481c0bb8b69bbf574ba90855e", null ],
    [ "pwd", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#aa8b37d9db6d75edbaece5556fa0f5234", null ],
    [ "ssid", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#aef57069f42cff72c4079d5ce0d325eca", null ],
    [ "timeout", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a97a613afaedc35a2a4a739ebde1fc24e", null ],
    [ "token", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a4bba75b8efb6d261cd3d3692a0a4fefd", null ],
    [ "uuid", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_bean.html#a91b2b9d3d5f7d14a3215fdbe268f95e1", null ]
];