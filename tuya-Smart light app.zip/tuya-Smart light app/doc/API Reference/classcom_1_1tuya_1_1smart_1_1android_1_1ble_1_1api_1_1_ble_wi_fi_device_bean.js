var classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean =
[
    [ "baselineVer", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#ad091733fca21cfebf94ccc8d8c56f565", null ],
    [ "cadVer", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a8ddb250bbc1795fd5f088a57b9f5685a", null ],
    [ "cdVer", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a7d123b5204ed1d02579894b6a96b8df6", null ],
    [ "devAttribute", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a80fd99267f3efcae0921a3840a7b6f43", null ],
    [ "devId", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a36b362a58d1c145527862d2527735ffc", null ],
    [ "encryptedAuthKey", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#ab3cfa3f3c32f86abea6713e42a517289", null ],
    [ "hid", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a0888752fc6e23c9db3bf17ba5240e37f", null ],
    [ "modulesOnline", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#ac2dc914f128be007b258a7e95a219f76", null ],
    [ "modulesOtaChannel", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a50b6fb27fcc1222399266c05e6ca83af", null ],
    [ "modulesSoftVer", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#af984410b45f964bcfb1b17e124f61edd", null ],
    [ "needBeaconKey", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a03d3e643fff584e3b2f674f6f44ce750", null ],
    [ "needSchema", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a4e273c963ba9301b2e983c661efb05f4", null ],
    [ "optionsIsFK", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a107f0a7865575e9bb5ca3460db28c380", null ],
    [ "optionsOtaChannel", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#afc230e34b21879dba3528cb09dae4b4f", null ],
    [ "optionsUdf", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#aa439bf5f7618487eca39c88d207cc34e", null ],
    [ "packetMaxSize", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#aa93a3270b01d73bfdd46bbcb0adb18a4", null ],
    [ "productKey", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#af0ab3c6aff4a790238bcb6d2abb4956b", null ],
    [ "productKeyStr", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a9f977de37df1a372eae56e04eee69d3d", null ],
    [ "protocolVer", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a344194ae0cf2c04e96ca58b38613ce35", null ],
    [ "softVer", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a5e3e5dea21f24a1dd8e6e8fed221094d", null ],
    [ "uuid", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_wi_fi_device_bean.html#a72184fc765c437670cad5e4920c93ec4", null ]
];