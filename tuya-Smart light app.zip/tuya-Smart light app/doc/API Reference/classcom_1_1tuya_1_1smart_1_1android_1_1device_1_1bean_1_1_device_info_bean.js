var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_info_bean =
[
    [ "getIcon", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_info_bean.html#a624a696bf98f90ceb57660b34747fe3d", null ],
    [ "getId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_info_bean.html#a9f49500d257dd9b1cafd359c074f564c", null ],
    [ "getName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_info_bean.html#adf60f5e88802e7cb16a25ae3b5931efc", null ],
    [ "setIcon", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_info_bean.html#aeddc231612eb35aa9620c5637be1d448", null ],
    [ "setId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_info_bean.html#ae122176de904acc41b17a001f685dc3a", null ],
    [ "setName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_info_bean.html#a4997ba59bd333d0fb1b446be49f54b37", null ]
];