var classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_update_bean =
[
    [ "devId", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_update_bean.html#aeffc59b297c9457350744d2e3a965f5b", null ],
    [ "devName", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_update_bean.html#a3df6a3d5ecaaf9bb4c953b30c166fe38", null ],
    [ "loginKey", "classcom_1_1tuya_1_1smart_1_1android_1_1ble_1_1api_1_1_ble_controller_update_bean.html#abeec1654bb02d095f3c4d72815a8a3fc", null ]
];