var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean =
[
    [ "getDevId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean.html#a88e4ff61b8eb4ba6a76b2afa54464616", null ],
    [ "getDpId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean.html#ad8079727909b6844d24c77612d7bb8bb", null ],
    [ "getId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean.html#ad39f1731ce614d07240830ff8cbcc92d", null ],
    [ "isEnable", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean.html#af74d083911672efe8cd85149b22ea390", null ],
    [ "setDevId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean.html#afec1ab089ffcda4244c77b39a888ba6a", null ],
    [ "setDpId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean.html#a51b16128782d1a6c928b4783d6b7821e", null ],
    [ "setEnable", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean.html#a273d075febd63252cdcb1d40ef448f33", null ],
    [ "setId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean.html#a74a6244014bc215aa184bb25fc166032", null ]
];