var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bitmap_schema_bean =
[
    [ "getMaxlen", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bitmap_schema_bean.html#affd29861861b88ee91bd55d133a88b09", null ],
    [ "setMaxlen", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bitmap_schema_bean.html#aa620cfbf8689e4f7cc2acab449a88051", null ],
    [ "type", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bitmap_schema_bean.html#a8bde6e716c835abb164ff5e8934c6eb4", null ]
];