var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean =
[
    [ "getDatapoints", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#ab0cc1134fc3dac4d9e7616c9e8566c51", null ],
    [ "getDevId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#ae4d4b3a7ce3267e1327ccdd1c81bf1e3", null ],
    [ "getDevName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a4a8982dd7e43a6d815fa7e249d587dd6", null ],
    [ "getDpId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a05305d799144eb01f038062cc1b267ef", null ],
    [ "getDpName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#abb2ad34613b53679b9a4ee100a44eb29", null ],
    [ "getId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a61fbabc9b09fe1bbe6c0403dcbd231a1", null ],
    [ "getMultiControlId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#addccf0319cf6da404f4af0b09ec1642e", null ],
    [ "getStatus", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#ae62a6f90ac2dc78d743cbb546fe17aa5", null ],
    [ "isEnabled", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a83eb375dc3083cc272580d09ba53ff31", null ],
    [ "setDatapoints", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a5530f548a2fa5f488d3b9f49792c3b38", null ],
    [ "setDevId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#af34d3b8d0cbdebe407cdf63d62562f43", null ],
    [ "setDevName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#ac7c838d8062a863a2712b4f50197f68e", null ],
    [ "setDpId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a4561a590229601e4fb0ac152fea88124", null ],
    [ "setDpName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a3570ec7c26da30aed909c9668339ed89", null ],
    [ "setEnabled", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a4cc0fa19606a62ae214dd8a427999b9c", null ],
    [ "setId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a8045a38a78f3b03311395ed8f23eb6d8", null ],
    [ "setMultiControlId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#ada34999f9d947fdcf3cdfa1711df5ffb", null ],
    [ "setStatus", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html#a67e84e1a608be74ef9ab83f179183578", null ]
];