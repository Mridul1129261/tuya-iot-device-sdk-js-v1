var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_datapoints_bean =
[
    [ "getDpId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_datapoints_bean.html#a2083c258ba0bd4984e237b67ce72a720", null ],
    [ "getName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_datapoints_bean.html#a83775eff9028d4c54314657963c5fcb7", null ],
    [ "setDpId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_datapoints_bean.html#a837b147c1210177182095b0028e3f686", null ],
    [ "setName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_datapoints_bean.html#ae41d4e2b6fe80a556e79511a4b676e43", null ]
];