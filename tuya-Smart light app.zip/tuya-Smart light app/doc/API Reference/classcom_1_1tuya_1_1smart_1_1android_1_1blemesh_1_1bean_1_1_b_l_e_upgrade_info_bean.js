var classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_info_bean =
[
    [ "getGw", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_info_bean.html#ad5b3070baab1bedcd383b2a9c50003b4", null ],
    [ "getUpgradeType", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_info_bean.html#a1d14a4a6c1a3daf384b7963a66328a85", null ],
    [ "getVersionHintMessage", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_info_bean.html#afa76e1b0089f16ca16a8a1b47fbd2475", null ],
    [ "isNeedUpgrade", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_info_bean.html#aaa3371d0acb60044782924e30a81c8c2", null ],
    [ "setGw", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_info_bean.html#a8461a9a92a768b488291e0e5ed13f83d", null ],
    [ "setVersionHintMessage", "classcom_1_1tuya_1_1smart_1_1android_1_1blemesh_1_1bean_1_1_b_l_e_upgrade_info_bean.html#a99c040bbbdb651bd7f4cbeb3f0ff5e56", null ]
];