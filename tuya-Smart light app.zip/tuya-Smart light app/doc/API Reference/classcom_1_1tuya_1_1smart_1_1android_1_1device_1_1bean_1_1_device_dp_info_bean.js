var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean =
[
    [ "getCode", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean.html#a3ab9791af20f452c7cfdc06a6cf806e1", null ],
    [ "getDpId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean.html#a7964805ed230f01c1360813f1c27e50f", null ],
    [ "getName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean.html#aa66e3b2ada2bf7d74b0d9d16f0546b4c", null ],
    [ "getSchemaId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean.html#af6b327aebac1dd4945cb87ec6e739a7d", null ],
    [ "setCode", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean.html#a11ea783550a7d38c8df96d3f0653cac3", null ],
    [ "setDpId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean.html#abb71dac86da98d302adecba8c525c772", null ],
    [ "setName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean.html#a8ac0b73a4b48322f7f0127f534f5249c", null ],
    [ "setSchemaId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_dp_info_bean.html#ae0e2676bf102cdfe7a0bf0258e7edef6", null ]
];