var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean =
[
    [ "GroupDetailBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_11f67722873e6fddccb1b4b7520613b1.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_11f67722873e6fddccb1b4b7520613b1" ],
    [ "getGroupDetail", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a770be666ee51ca15a02ebc01515e4bb6", null ],
    [ "getGroupName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#aa9d5b64fda810981e90547d6295f2c64", null ],
    [ "getGroupType", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a148e3d35b84afe0db4ddcdb6702ea732", null ],
    [ "getId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a9fdc8e2ddfe1744c7508c52a279b2466", null ],
    [ "getMultiControlId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a9d812da1ef11934a5cef4adfb1118fb3", null ],
    [ "getMultiRuleId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a00107a78ba08c57b8102d8ef1d2986d7", null ],
    [ "getOwnerId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a9b33b4504ce97b73ea7ae0bf81805142", null ],
    [ "getStatus", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a73ab21c281b3b7fad046d77091cbf35a", null ],
    [ "getUid", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a39f6e5187e6ae1cdaf7803a431c45bd2", null ],
    [ "isEnabled", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a26a412db7c492262241352ce5ddd7403", null ],
    [ "setEnabled", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a867ae132c5275689e6635eeb923d2ff8", null ],
    [ "setGroupDetail", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#ac3cf5dcb47542ddee3184689570d92bf", null ],
    [ "setGroupName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a862e1ef75293e9528132a03a4d03747b", null ],
    [ "setGroupType", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a211f941f71acedbf65df2581f3b2b201", null ],
    [ "setId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a9246db9dbe5f54dfd3676b4cf342b795", null ],
    [ "setMultiControlId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#aa01341d53432825c6098674bd8df7ac8", null ],
    [ "setMultiRuleId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#afb474e3c2a2599612787c70d67a4ec59", null ],
    [ "setOwnerId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#a7363edeeffb83f3bed2c35fc5ece1247", null ],
    [ "setStatus", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#aaab3aa37bf1f525dcda62be74e7457ea", null ],
    [ "setUid", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_device_multi_control_relation_bean_1_1_mc_groups_bean.html#aca0a13edcdef44f933c4cc04b2220397", null ]
];