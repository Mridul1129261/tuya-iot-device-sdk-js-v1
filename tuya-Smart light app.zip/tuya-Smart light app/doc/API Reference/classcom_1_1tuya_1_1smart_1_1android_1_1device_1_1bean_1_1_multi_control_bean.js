var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean =
[
    [ "GroupDetailBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean_1_1_group_detail_bean" ],
    [ "getGroupDetail", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean.html#aa611677e5f0f744804c9bc256851dd4b", null ],
    [ "getGroupName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean.html#a7a2a709b0f171382ae6c4f76f9a63ebc", null ],
    [ "getGroupType", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean.html#a6c75383d0915f803eee4d880ef71473b", null ],
    [ "getId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean.html#a70f50b0b66899a7527fd757df5929a17", null ],
    [ "setGroupDetail", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean.html#a6045638c904e4d58b180479b2df5814c", null ],
    [ "setGroupName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean.html#a662f7fc7e373ab91b156fa3755c1a58f", null ],
    [ "setGroupType", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean.html#aab9c08975b2fa8793d87f1af24ee7738", null ],
    [ "setId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_bean.html#a93dcb2360b8c79ffbd7b8f8e3e87bd49", null ]
];