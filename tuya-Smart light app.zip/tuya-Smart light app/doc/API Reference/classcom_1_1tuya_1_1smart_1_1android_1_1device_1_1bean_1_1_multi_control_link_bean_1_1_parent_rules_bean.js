var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_parent_rules_bean =
[
    [ "getId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_parent_rules_bean.html#a7e200d699263039a0afa93111df50e12", null ],
    [ "getName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_parent_rules_bean.html#a491e1dc492942abf3a936e4d12a795f0", null ],
    [ "setId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_parent_rules_bean.html#a79ae1a7ef148173b9d9d325a75fe370f", null ],
    [ "setName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_parent_rules_bean.html#a390bd3ca13affddce40f0891da1d90c7", null ]
];