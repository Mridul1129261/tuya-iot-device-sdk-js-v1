var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean =
[
    [ "GroupDetailBean", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean.html", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean_1_1_group_detail_bean" ],
    [ "getGroupDetail", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a665298bc668a5411347bfb6d157a4956", null ],
    [ "getGroupName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a7febcdade42cc7f2051a2be51d2ff206", null ],
    [ "getGroupType", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a09e664b54bd7d19b07ff926c528d80fd", null ],
    [ "getId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a679492d6756548da78cae34171c85614", null ],
    [ "getMultiRuleId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a88f8224f2a853cd76561b5c8c58b677d", null ],
    [ "getOwnerId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a8a5abddb28c5d6d00699a63ade9e3a4c", null ],
    [ "getStatus", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#afa1c992133bc8908b776ec9e1267b49c", null ],
    [ "getUid", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a3233d0f04f2d44dce7570064eae14952", null ],
    [ "isEnabled", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#ab3f5b48879b8728d123802868d40bf53", null ],
    [ "setEnabled", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#af7abccb3e062001f134d798c4f320243", null ],
    [ "setGroupDetail", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a64a994285810447c73b5c16c0b47bd45", null ],
    [ "setGroupName", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a1514c9501ae104f1de8b53bdcf42d915", null ],
    [ "setGroupType", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a934ec42fd7c4786431d87f1a51c80d1d", null ],
    [ "setId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a4a3c50710185a66b49498b9e2fec61b7", null ],
    [ "setMultiRuleId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a0d48713bd1b7730d6b603570185b8158", null ],
    [ "setOwnerId", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a5c7d87a502cca7e037f0edad8cdebd5e", null ],
    [ "setStatus", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#ad5f5ca00645de02b4c54092b4a096e39", null ],
    [ "setUid", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_multi_control_link_bean_1_1_multi_group_bean.html#a2651ff7b4c69bc4a75673c34882bc96b", null ]
];