var classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bool_schema_bean =
[
    [ "type", "classcom_1_1tuya_1_1smart_1_1android_1_1device_1_1bean_1_1_bool_schema_bean.html#a82c8e67939037e60072142f0de82a946", null ]
];